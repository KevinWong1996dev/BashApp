<template>
    <GridLayout height="80" columns="*,auto,*" class="header">
        <Label text.decode="&#xf060;" fontSize="20" col="0" class="fa android-lbl" textAlignment="center" verticalAlignment="center" horizontalAlignment="left"></Label>
        <Label text="PERFIL ANFITRION" fontSize="20" col="1" class="fa android-lbl" textAlignment="center" verticalAlignment="center" horizontalAlignment="center"></Label>
        <Label text.decode="&#xf142;" fontSize="20" col="2" class="fa android-lbl" textAlignment="center" verticalAlignment="center" horizontalAlignment="right"></Label>
    </GridLayout>
</template>


<style scoped>
.fa {
    margin: 10;
    color: #000;
}
</style>