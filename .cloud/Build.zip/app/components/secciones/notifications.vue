<template>
  <GridLayout row="0" columns="*, *" marginTop="5">
    <Label
      col="0"
      text="FOLLOWING"
      fontSize="20"
      padding="5"
      color="#cccccc"
      textAlignment="center"
      style="border-bottom-width: 1; border-bottom-color: #cccccc;"
    ></Label>
    <Label
      col="1"
      text="YOU"
      fontSize="20"
      padding="5"
      color="black"
      textAlignment="center"
      style="border-bottom-width: 1; border-bottom-color: black;"
    ></Label>
  </GridLayout>
</template>

<script>
export default {};
</script>
